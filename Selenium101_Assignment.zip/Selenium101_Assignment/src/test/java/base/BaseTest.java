package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.MutableCapabilities;
import org.testng.annotations.*;
import java.net.URL;

public class BaseTest {

    protected WebDriver driver;

    @Parameters({"browser", "platform", "version"})
    @BeforeMethod
    public void setUp(
            @Optional("chrome") String browser,
            @Optional("Windows 10") String platform,
            @Optional("latest") String version
    ) throws Exception {

        String username = "sameebaig";  // 🔑 your LambdaTest 
        String accessKey = "LT_uGgklOlCMhCmjdUO9328scQtX1iDjAp00sc7a7C7Ulpo0Rg"; // 🔑 your access key

        // ✅ Use W3C-compliant LT:Options instead of deprecated DesiredCapabilities
        MutableCapabilities capabilities = new MutableCapabilities();
        capabilities.setCapability("browserName", browser);
        capabilities.setCapability("browserVersion", version);

        // ✅ LambdaTest specific options
        MutableCapabilities ltOptions = new MutableCapabilities();
        ltOptions.setCapability("build", "Selenium 101 Assignment");
        ltOptions.setCapability("name", this.getClass().getSimpleName());
        ltOptions.setCapability("platformName", platform);
        ltOptions.setCapability("project", "LambdaTest Selenium 101");
        ltOptions.setCapability("selenium_version", "4.21.0");
        ltOptions.setCapability("w3c", true);
        ltOptions.setCapability("console", true);
        ltOptions.setCapability("network", true);
        ltOptions.setCapability("visual", true);
        ltOptions.setCapability("video", true);

        // ✅ Attach LT options under "LT:Options" as per new spec
        capabilities.setCapability("LT:Options", ltOptions);

        driver = new RemoteWebDriver(
                new URL("https://" + username + ":" + accessKey + "@hub.lambdatest.com/wd/hub"),
                capabilities
        );

        driver.manage().window().maximize();
        driver.get("https://www.lambdatest.com/selenium-playground/");
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
