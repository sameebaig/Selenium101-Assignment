package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SimpleFormDemo {
    WebDriver driver;

    By messageInput = By.id("user-message");
    By getCheckedValueBtn = By.id("showInput");
    By outputMessage = By.id("message");

    public SimpleFormDemo(WebDriver driver) {
        this.driver = driver;
    }

    public void enterMessage(String msg) {
        driver.findElement(messageInput).sendKeys(msg);
    }

    public void clickGetCheckedValue() {
        driver.findElement(getCheckedValueBtn).click();
    }

    public String getDisplayedMessage() {
        return driver.findElement(outputMessage).getText();
    }
}
