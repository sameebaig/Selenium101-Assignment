package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class DragDropSlidersPage {
    WebDriver driver;

    public DragDropSlidersPage(WebDriver driver) {
        this.driver = driver;
    }

    public void moveSliderTo95() {
        WebElement slider = driver.findElement(By.xpath("//input[@value='15']"));
        WebElement range = driver.findElement(By.id("rangeSuccess"));

        Actions act = new Actions(driver);
        act.dragAndDropBy(slider, 210, 0).perform(); // adjust if needed
    }

    public String getRangeValue() {
        return driver.findElement(By.id("rangeSuccess")).getText();
    }
}
