package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class InputFormSubmitPage {

    WebDriver driver;

    public InputFormSubmitPage(WebDriver driver) {
        this.driver = driver;
    }

    public void fillForm() {
        driver.findElement(By.id("name")).sendKeys("Sameen Baig");
        driver.findElement(By.id("inputEmail4")).sendKeys("sameen@example.com");
        driver.findElement(By.id("inputPassword4")).sendKeys("Password123");
        driver.findElement(By.id("company")).sendKeys("VentureDive");
        driver.findElement(By.id("websitename")).sendKeys("www.venturedive.com");

        Select country = new Select(driver.findElement(By.name("country")));
        country.selectByVisibleText("United States");

        driver.findElement(By.id("inputCity")).sendKeys("New York");
        driver.findElement(By.id("inputAddress1")).sendKeys("123 Main Street");
        driver.findElement(By.id("inputAddress2")).sendKeys("Suite 4B");
        driver.findElement(By.id("inputState")).sendKeys("NY");
        driver.findElement(By.id("inputZip")).sendKeys("10001");
    }

    public void clickSubmit() {
        driver.findElement(By.xpath("//button[normalize-space()='Submit']")).click();
    }

    public String getSuccessMessage() {
        return driver.findElement(By.cssSelector(".success-msg")).getText().trim();
    }

    public String getValidationMessage() {
        return driver.findElement(By.id("name")).getAttribute("validationMessage");
    }
}
